﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XMLTest
{
    public class Process
    {
        public void ProcessXML(string path)
        {
            var files = CheckFileExistsInFolder(path);
            foreach (var file in files)
            {
                ProcessFile(file);
            }
            Console.WriteLine("Completed.");
        }
        public void ProcessFile(string file)
        {
            string fileType = System.IO.Path.GetExtension(file);
            switch (fileType)
            {
                case (".xml"):
                    XMLFile xMLFile = new XMLFile();
                    BackupFile(file);
                    xMLFile.ReplaceFileContent(file, "Trisoft", "SDL Trisoft");
                    Console.WriteLine("File updated successfully.");
                    break;
                case (".xsl"):
                    break;
                default:
                    break;

            }
        }
        public void BackupFile(string path)
        {
            string backupFilepath = path + ".bak";
            if (System.IO.File.Exists(path) == true && !System.IO.File.Exists(backupFilepath))
            {
                System.IO.File.Copy(path, backupFilepath);
            }
        }
        public string[] CheckFileExistsInFolder(string path)
        {
            var files = System.IO.Directory.GetFiles(path);
            if (files.Length == 0)
            {
                Console.WriteLine("There are no files to update");
            }
            return files;
        }
    }
}
