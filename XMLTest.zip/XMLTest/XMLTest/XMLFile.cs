﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace XMLTest
{
    public class XMLFile
    {
        public void ReplaceFileContent(string filePath, string oldValue,string newValue)
        {
           try
            {
                XDocument doc = XDocument.Load(filePath);                
                var decendants = doc.Descendants("test");
                Process process = new Process();
                foreach (XElement kid in decendants)
                {
                    kid.FirstAttribute.Value = kid.FirstAttribute.Value.Replace(oldValue, newValue);
                    kid.SetElementValue("line1",kid.Value.Replace(oldValue, newValue));
                } 
                doc.Save(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }       
    }
}
