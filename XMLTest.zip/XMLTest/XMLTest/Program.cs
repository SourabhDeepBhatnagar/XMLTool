﻿using System;

namespace XMLTest
{
    class Program
    {
        static void Main(string[] args)
        {
            var path = @"d:\XML";
            Process process = new Process();
            process.ProcessXML(path);
            Console.ReadKey();
        }
    }
}
