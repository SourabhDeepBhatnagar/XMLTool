﻿using System;
namespace TestSolution
{
    class Program
    {
        // Getting some Issues with Nunit on Local laptop so creating methods for unit testing directly
        static void Main(string[] args)
        {
           
        }

            }
}
