﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using XMLTest;
using System;
using System.Collections.Generic;
using System.Text;

namespace XMLTest.Tests
{
    [TestClass()]
    public class XMLFileTests
    {
        [TestMethod()]
        public void ReplaceFileContentTest()
        {
            var filePath = @"D:\XML\first.xml";
            var oldValue = "Trisoft";
            var newValue = "SDL Trisoft";
            XMLTest.XMLFile xMLFile = new XMLFile();
            xMLFile.ReplaceFileContent(filePath, oldValue, newValue);
            Assert.IsTrue(true);
        }
    }
}