﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using XMLTest;
using System;
using System.Collections.Generic;
using System.Text;

namespace XMLTest.Tests
{
    [TestClass()]
    public class ProcessTests
    {
        [TestMethod()]
        public void ProcessXMLTest()
        {
            var folder = @"D:\XML";
            XMLTest.Process process = new Process();
            var files = process.CheckFileExistsInFolder(folder);
            bool getFiles = files.Length > 1;
            Assert.IsTrue(getFiles);
        }

        [TestMethod()]
        public void BackupFileTest()
        {
            var file = @"D:\XML\first.xml";
            XMLTest.Process process = new Process();
            process.BackupFile(file);
            Assert.IsTrue(true);
        }

        [TestMethod()]
        public void ProcessFileTest()
        {
            var file = @"D:\XML\first.xml";
            XMLTest.Process process = new Process();
            process.ProcessFile(file);
            Assert.IsTrue(true);
        }
    }
}